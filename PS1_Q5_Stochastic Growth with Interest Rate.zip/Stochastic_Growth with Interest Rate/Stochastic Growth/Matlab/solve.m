%% File Info.

%{

    solve.m
    -------
    This code solves the model.

%}

%% Solve class.

classdef solve
    methods(Static)
        %% Solve the model using VFI. 
        
        function sol = grow(par)            
            %% Structure array for model solution.
            
            sol = struct();
            
            %% Model parameters, grids and functions.
            
            beta = par.beta; % Discount factor.
            alpha = par.alpha; % Capital share.
            delta = par.delta; % Depreciation rate.

            klen = par.klen; % Grid size for k.
            kgrid = par.kgrid; % Grid for k (state and choice).

            Alen = par.Alen; % Grid size for A.
            Agrid = par.Agrid; % Grid for A.
            pmat = par.pmat; % Grid for A.

            rlen = par.rlen; % Grid size for r (real interest rate).
            rgrid = par.rgrid; % Grid for real interest rate.
            prmat = par.rmat; % Transition matrix for r.

            kmat = repmat(kgrid,1,Alen,rlen); % k for each value of A. (klen x alen x rlen)
            Amat = repmat(Agrid,klen,1,rlen); % A for each value of k. (klen x alen x rlen)
            rmat = repmat(reshape(rgrid,1,1,rlen),klen,Alen,1); % r for each combination of k and A. (klen x alen x rlen)


            %% Value Function Iteration.
            
            y0 = Amat.*kmat.^alpha; % Assume you have the deterministic steady-state capital.
            i0 = delta*kgrid; % In the deterministic steady state, k=k'=k*.
            c0 = y0-i0; % Steady-state consumption in a deterministic setting.
            v0 = model.utility(Amat.*(kmat.^alpha)-(delta.*kmat),par)./(1-beta); % Guess of value function.

            v1 = zeros(klen,Alen,rlen); % Container for V.
            k1 = zeros(klen,Alen,rlen); % Container for k'.
                            
            crit = 1e-6;
            maxiter = 10000;
            diff = 1;
            iter = 0;
            
            fprintf('------------Beginning Value Function Iteration.------------\n\n')
            
            while diff > crit && iter < maxiter % Iterate on the Bellman Equation until convergence.
                
                for p = 1:klen % Loop over the k-state space and maximize.
                    for j = 1:Alen % Loop over the A-state space and maximize.
                        for m = 1:rlen % Loop over the r-state space and maximize.
                            y = rgrid(m) * kgrid(p) + Agrid(j) * (kgrid(p)^alpha) - kgrid(p) * Agrid(j) * alpha * (kgrid(p)^(alpha - 1)); % Income given state k, kgrid(p), and given state A, Agrid(j).
                            i = kgrid-(1-delta)*kgrid(p); % Investment, i=k'-(1-delta)k, for a given state of k, kgrid(p), and the vector of choices for k', kgrid.
                            c = max(y-i,0); % Consumption, c = y-i.

                            EV = zeros(klen,rlen);
                            for mm = 1:rlen
                                EV(:,mm) = squeeze(v0(:,:,mm))*pmat(j,:)';
                            end

                            vall = model.utility(c, par) + beta .* (EV*prmat(m,:)'); % Compute the Bellman equation for each choice of k', given a particular state of k.
                            vall(c<=0) = -inf; % Set the value function to negative infinity when c <= 0.
                            [vmax,ind] = max(vall); % Maximize.
                            v1(p,j,m) = vmax;
                            k1(p,j,m) = kgrid(ind);
                        end
                    end
                end
                
                diff = norm(v1-v0, "fro"); % Check convergence.
                v0 = v1; % Update guess.
                
                iter = iter + 1; % Update counter.
                
                % Print counter.
                if mod(iter,25) == 0
                    fprintf('Iteration: %d.\n',iter)
                end

            end
                
            fprintf('\nConverged in %d iterations.\n\n',iter)
            
            fprintf('------------End of Value Function Iteration.------------\n')
            
            %% Value and policy functions.
            
            sol.y = rmat .* kmat + Amat .* (kmat .^ alpha) - (kmat .* Amat .* alpha .* kmat .^ (alpha - 1));    % Output 
            sol.c = max(((1 - delta + rmat) .* kmat) - k1 + (Amat .* (kmat .^ alpha)) - (kmat .* Amat .* alpha .* kmat .^ (alpha - 1)), 0); % Consumption policy function.
            sol.k = k1; % Capital policy function.
            sol.v = v1; % Value function.
            sol.i = k1-((1-delta).*kmat); % Investment policy function.
            
        end
        
    end
end