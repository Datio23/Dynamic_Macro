%% File Info.

%{

    my_graph.m
    ----------
    This code plots the value and policy functions.

%}

%% Graph class.

classdef my_graph
    methods(Static)
        %% Plot value and policy functions.
        
        function [] = plot_policy(par,sol,sim,figout)
            %% Plot capital policy function.
            
            figure(1)
            
            plot(par.kgrid,squeeze(sol.k(:,end,:)))
                xlabel({'$k_{t}$'},'Interpreter','latex')
                ylabel({'$k_{t+1}$'},'Interpreter','latex') 
            title('Capital Policy Function')
            
            fig1name = strcat(figout,'kpol.fig');
            savefig(fig1name)
            
            %% Plot consumption policy function.
            
            figure(2)
            
            plot(par.kgrid,squeeze(sol.c(:,end,:)))
                xlabel({'$k_{t}$'},'Interpreter','latex')
                ylabel({'$c_{t}$'},'Interpreter','latex') 
            title('Consumption Policy Function')
            
            fig2name = strcat(figout,'cpol.fig');
            savefig(fig2name)
            
            %% Plot value function.
            
            figure(3)
            
            plot(par.kgrid,squeeze(sol.v(:,end,:)))
                xlabel({'$k_{t}$'},'Interpreter','latex')
                ylabel({'$v_t(W_t)$'},'Interpreter','latex') 
            title('Value Function')

            fig3name = strcat(figout,'vfun.fig');
            savefig(fig3name)

            %% Plot simulated consumption.

            tgrid = linspace(1,par.T,par.T);

            figure(4)

            plot(tgrid,sim.csim)
                xlabel({'Time'},'Interpreter','latex')
                ylabel({'$c^{sim}_t$'},'Interpreter','latex') 
            title('Simulated Consumption')

            fig4name = strcat(figout,'csim.fig');
            savefig(fig4name)

            %% Plot simulated capital stock.

            figure(5)

            plot(tgrid,sim.ksim)
                xlabel({'Time'},'Interpreter','latex')
                ylabel({'$k^{sim}_t$'},'Interpreter','latex') 
            title('Simulated Capital Stock')

            fig5name = strcat(figout,'ksim.fig');
            savefig(fig5name)

            %% Plot simulated utility.

            figure(6)

            plot(tgrid,sim.usim)
                xlabel({'Time'},'Interpreter','latex')
                ylabel({'$u^{sim}_t$'},'Interpreter','latex') 
            title('Simulated Utility')

            fig6name = strcat(figout,'usim.fig');
            savefig(fig6name)


            %% Plot simulated productivity.

            figure(7)

            plot(tgrid,sim.Asim)
                xlabel({'Time'},'Interpreter','latex')
                ylabel({'$A^{sim}_t$'},'Interpreter','latex') 
            title('Productivity')

            fig7name = strcat(figout,'Asim.fig');
            savefig(fig7name)
            
            %% Plot simulated real interest rate.

            figure(8)
            plot(tgrid, sim.rsim)
            xlabel({'Time'}, 'Interpreter', 'latex')
            ylabel({'$r^{sim}_t$'}, 'Interpreter', 'latex') 
            title('Simulated Real Interest Rate')
            fig8name = strcat(figout, 'rsim.fig');
            savefig(fig8name)

            %% Plot consumption policy function (to both k and r)
            
            c_slice = squeeze(sol.c(:, 1, :));
            [k_mat, r_mat] = meshgrid(par.kgrid, par.rgrid);
            c_plot = c_slice';

            figure(9)
            
            surf(k_mat, r_mat, c_plot);
                xlabel('$k_t$', 'Interpreter','latex');
                ylabel('$r_t$', 'Interpreter','latex');
                zlabel('$c(k_t,r_t)$', 'Interpreter','latex');
            title('Consumption Policy Function (with k and r)')
            
            fig9name = strcat(figout,'cpol2.fig');
            savefig(fig9name)

            %% Plot consumption policy function (to both A and r)

            c_slice2 = squeeze(sol.c(1, :, :));
            [A_mat, r_mat] = meshgrid(par.Agrid, par.rgrid);
            c_plot2 = c_slice2';

            figure(10)
            
            surf(A_mat, r_mat, c_plot2);
                xlabel('$A_t$', 'Interpreter','latex');
                ylabel('$r_t$', 'Interpreter','latex');
                zlabel('$c(A_t,r_t)$', 'Interpreter','latex');
            title('Consumption Policy Function (with A and r)')
            
            fig10name = strcat(figout,'cpol3.fig');
            savefig(fig10name)

            %% Plot consumption policy function (to both k and A)

            c_slice3 = squeeze(sol.c(:, :, 1));
            [k_mat, A_mat] = meshgrid(par.kgrid, par.Agrid);
            c_plot3 = c_slice3';

            figure(11)
            
            surf(k_mat, A_mat, c_plot3);
                xlabel('$k_t$', 'Interpreter','latex');
                ylabel('$A_t$', 'Interpreter','latex');
                zlabel('$c(k_t,A_t)$', 'Interpreter','latex');
            title('Consumption Policy Function (with k and A)')
            
            fig11name = strcat(figout,'cpol4.fig');
            savefig(fig11name)

            %% Plot simulated capital stock.

            figure(12)

            plot(tgrid,sim.isim)
                xlabel({'Time'},'Interpreter','latex')
                ylabel({'$i^{sim}_t$'},'Interpreter','latex') 
            title('Simulated Investment')

            fig12name = strcat(figout,'isim.fig');
            savefig(fig12name)

            %% Plot investment policy function.
            
            figure(13)
            
            plot(par.kgrid,squeeze(sol.i(:,end,:)))
                xlabel({'$k_{t}$'},'Interpreter','latex')
                ylabel({'$i_{t}$'},'Interpreter','latex') 
            title('Investment Policy Function')
            
            fig13name = strcat(figout,'ipol.fig');
            savefig(fig13name)

            %% Plot production function
            
            figure(14)
            
            plot(par.kgrid,squeeze(sol.y(:,end,:)))
                xlabel({'$k_{t}$'},'Interpreter','latex')
                ylabel({'$y_{t}$'},'Interpreter','latex') 
            title('Production Function')
            
            fig14name = strcat(figout,'ypol.fig');
            savefig(fig14name)

            %% Plot simulated output 

            figure(15)
            
            plot(tgrid,sim.ysim)
            xlabel({'Time'},'Interpreter','latex')
            ylabel({'$y^{sim}_t$'},'Interpreter','latex')
            title('Simulated Output')

            fig15name = strcat(figout,'ysim.fig');
            savefig(fig15name)




        end
        
    end
end