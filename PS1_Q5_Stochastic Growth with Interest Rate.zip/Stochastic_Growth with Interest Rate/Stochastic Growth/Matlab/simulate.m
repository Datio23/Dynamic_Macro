%% File Info.

%{

    simulate.m
    ----------
    This code simulates the model.

%}

%% Simulate class.

classdef simulate
    methods(Static)
        %% Simulate the model. 
        
        function sim = grow(par,sol)            
            %% Set up.
            
            kgrid = par.kgrid; % Capital state variable.
            Agrid = par.Agrid; % Productivity state variable.
            rgrid = par.rgrid; % Real interest rate state variable.

            yout = sol.y; % Production function.
            kpol = sol.k; % Capital policy function.
            cpol = sol.c; % Consumption policy function.
            ipol = sol.i; % Policy function for investment.

            T = par.T; % Time periods.
            ysim = zeros(par.T*2,1); % Container for simulated output.
            Asim = zeros(par.T*2,1); % Container for simulated productivity.
            csim = zeros(par.T*2,1); % Container for simulated consumption.
            ksim = zeros(par.T*2,1); % Container for simulated capital stock.
            usim = zeros(par.T*2,1); % Container for simulated value function.
            rsim = zeros(par.T*2,1); % Container for simulated value function.
            isim = zeros(par.T*2, 1); % Container for simulated investment.
            
            %% Begin simulation.
            
            rng(par.seed);

            % Stationary distribution for A (productivity).
            pmat0 = par.pmat^1000;
            pmat0 = pmat0(1,:); % Stationary distribution.
            cmat = cumsum(par.pmat,2); % CDF matrix for A.

            % Stationary distribution for r (real interest rate).
            rmat0 = par.rmat^1000;
            rmat0 = rmat0(1,:); % Stationary distribution for r.
            rcmat = cumsum(par.rmat,2); % CDF matrix for r.

            A0_ind = randsample(par.Alen,1,true,pmat0); % Initial capital stock index.
            k0_ind = randsample(par.klen,1); % Initial capital stock index.
            r0_ind = randsample(par.rlen, 1, true, rmat0); % Initial r index.

            ysim(1) = yout(k0_ind,A0_ind, r0_ind); % Output in period 1 given k0 and A0.
            Asim(1) = Agrid(A0_ind); % Period 1 productivity.
            rsim(1) = rgrid(r0_ind); % Period 1 interest rate.
            csim(1) = cpol(k0_ind,A0_ind,r0_ind); % Period 1 consumption.
            ksim(1) = kpol(k0_ind,A0_ind,r0_ind); % Period 1 capital stock.
            isim(1) = ipol(k0_ind,A0_ind,r0_ind); % Investment in period 1 given k0 and A0.
            usim(1) = model.utility(csim(1),par); % Period 1 value function.

            A1_ind = find(rand<=cmat(A0_ind,:)); % Draw productivity for next period.
            A0_ind = A1_ind(1);

            r1_ind = find(rand <= rcmat(r0_ind,:)); % Draw new r for next period.
            r0_ind = r1_ind(1); % Update r index.

            %% Simulate endogenous variables.

            for j = 2:T*2 % Time loop.
                k_ind = find(ksim(j-1)==kgrid); % Find where capital policy is on the capital state grid.
                kt_ind = k_ind(1); % Update index for current period.

                Asim(j) = Agrid(A0_ind); % Period t productivity.
                rsim(j) = rgrid(r0_ind); % Period t interest rate.

                ysim(j) = yout(kt_ind,A0_ind,r0_ind); % Period t consumption.
                csim(j) = cpol(kt_ind,A0_ind,r0_ind); % Period t consumption.
                ksim(j) = kpol(kt_ind,A0_ind,r0_ind); % Period t capital stock.
                isim(j) = ipol(kt_ind,A0_ind,r0_ind); % Investment in period t.
                usim(j) = model.utility(csim(j),par); % Period t value function.
                

                A1_ind = find(rand<=cmat(A0_ind,:)); % State next period.
                A0_ind = A1_ind(1); % Update index for next period.

                r1_ind = find(rand <= rcmat(r0_ind,:)); 
                r0_ind = r1_ind(1); % Update r index.
            end

            sim = struct();
            
            % Burn the first half.
            sim.ysim = ysim(T+1:2*T,1); % Simulated output.
            sim.Asim = Asim(T+1:2*T,1); % Simulated productivity.
            sim.ksim = ksim(T+1:2*T,1); % Simulated capital stock.
            sim.csim = csim(T+1:2*T,1); % Simulate consumption.
            sim.usim = usim(T+1:2*T,1); % Simulated utility function.
            sim.rsim = rsim(T+1:2*T, 1); % Simulated real interest rate.
            sim.isim = isim(T+1:2*T, 1);  % Simulated investment 
             
        end
        
    end
end